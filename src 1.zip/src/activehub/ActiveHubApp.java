package activehub;

import ActiveHubModel.*;
import ActiveHubPayment.*;
import ActiveHubPromo.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

// Main function
public class ActiveHubApp {
    private Scanner scanner = new Scanner(System.in);
    private List<Item> catalogue = new ArrayList<>();
    private List<Promotion> promotions = new ArrayList<>();
    private Map<String, Booking> bookings = new HashMap<>();
    private Map<String, Transaction> transactions = new HashMap<>();
    private int nextBookingNumber = 1;
    private int nextTransactionNumber = 1;

    public ActiveHubApp() {
        initCatalogue();
        initPromotions();
    }

    public static void main(String[] args) {
        ActiveHubApp app = new ActiveHubApp();
        app.run();
    }


    // Item Catalogue using catalogue.
    private void initCatalogue() {
        catalogue.add(new Item("EQ1", "Badminton Racket", ItemCategory.EQUIPMENT, 10.00));
        catalogue.add(new Item("EQ2", "Shuttlecock Tube", ItemCategory.EQUIPMENT, 15.00));
        catalogue.add(new Item("EQ3", "Basketball", ItemCategory.EQUIPMENT, 8.00));
        catalogue.add(new Item("EQ4", "Futsal Ball", ItemCategory.EQUIPMENT, 8.00));
        catalogue.add(new Item("FC1", "Badminton Court (1 hr)", ItemCategory.FACILITY, 25.00));
        catalogue.add(new Item("FC2", "Futsal Court (1 hr)", ItemCategory.FACILITY, 80.00));
        catalogue.add(new Item("FC3", "Basketball Court (1 hr)", ItemCategory.FACILITY, 60.00));
        catalogue.add(new Item("AC1", "Grip Tape", ItemCategory.ACCESSORY, 5.00));
        catalogue.add(new Item("AC2", "Sports Towel", ItemCategory.ACCESSORY, 7.00));
    }

    // Initializing existing promotions
    private void initPromotions() {
        promotions.add(new OffPeakPromotion());
        promotions.add(new TeamBookingPromotion());
        promotions.add(new EquipmentBundlePromotion());
    }


    // Menu system
    public void run() {
        System.out.println("=== ActiveHub Sports Centre Management System ===");
        boolean running = true;

        while (running) {
            System.out.println("\n1. Facility Booking Management");
            System.out.println("2. View Rental Catalogue");
            System.out.println("3. Create / Modify Rental Transaction");
            System.out.println("4. Checkout & Payment");
            System.out.println("5. End-of-Day Manager Summary Report");
            System.out.println("6. Exit");

            int choice = readInt("Select an option: ", 1, 6);
            switch (choice) {
                case 1:
                    bookingMenu();
                    break;
                case 2:
                    showCatalogue();
                    break;
                case 3:
                    transactionMenu();
                    break;
                case 4:
                    checkout();
                    break;
                case 5:
                    showReport();
                    break;
                case 6:
                    System.out.println("Thank you for visiting ActiveHub.");
                    running = false;
                    break;
            }
        }
    }


    // Sport booking menu
    private void bookingMenu() {
        System.out.println("\n--- Facility Booking Management ---");
        System.out.println("1. Create Booking");
        System.out.println("2. View All Bookings");
        System.out.println("3. Cancel Booking");
        System.out.println("4. Return to Main Menu");

        int choice = readInt("Select an option: ", 1, 4);
        switch (choice) {
            case 1:
                createBooking();
                break;
            case 2:
                showBookings();
                break;
            case 3:
                cancelBooking();
                break;
            case 4:
                break;
        }
    }

    private void createBooking() {
        System.out.println("\n--- Create Facility Booking ---");
        showFacilities();

        String code = readNonBlank("Facility code: "); // falls back if error
        Item facility = findItem(code);
        if (facility == null || facility.getCategory() != ItemCategory.FACILITY) {
            System.out.println("Invalid facility code.");
            return;
        }

        String name = readNonBlank("Customer name: ");
        String contact = readNonBlank("Contact number: ");
        LocalDate date = readDate("Booking date (yyyy-MM-dd): ");
        LocalTime time = readTime("Booking time (HH:mm): ");
        int participants = readInt("Number of participants: ", 1, 500);

        // Check if facility is already booked at the same date and time
        for (Booking existing : bookings.values()) {
            if (existing.getStatus() == BookingStatus.CONFIRMED
                    && existing.getFacilityItem().getItemCode().equalsIgnoreCase(facility.getItemCode())
                    && existing.getBookingDate().equals(date)
                    && existing.getBookingTime().equals(time)) {
                System.out.println("That facility already has a confirmed booking at that date and time.");
                return;
            }
        }

        String id = String.format("B%04d", nextBookingNumber++);
        Booking booking = new Booking(id, name, contact, date, time, participants, facility);
        bookings.put(id, booking);
        System.out.println("Booking confirmed. Booking ID: " + id); // Prints booking id after booking is confirmed
    }

    private void showBookings() {
        System.out.println("\n--- Bookings ---");
        if (bookings.isEmpty()) { // Getter for booking
            System.out.println("No bookings found.");
            return;
        }

        for (Booking b : bookings.values()) {
            System.out.printf("%s | %s | %s | %s %s | %d participant(s) | %s/n",
                    b.getBookingId(), b.getCustomerName(), b.getFacilityItem().getItemName(),
                    b.getBookingDate(), b.getBookingTime(), b.getParticipants(), b.getStatus());
        }
    }

    private void cancelBooking() {
        showBookings();
        if (bookings.isEmpty()) {
            return;
        }

        String id = readNonBlank("Booking ID to cancel: ").toUpperCase();
        Booking booking = bookings.get(id);

        if (booking == null) {
            System.out.println("Booking not found.");
        } else if (booking.getStatus() == BookingStatus.CANCELLED) {
            System.out.println("That booking is already cancelled.");
        } else {
            booking.cancel();
            System.out.println("Booking " + booking.getBookingId() + " cancelled.");
        }
    }


    // Transaction menu prompt
    private void transactionMenu() {
        System.out.println("\n--- Create / Modify Rental Transaction ---");
        System.out.println("1. Create Transaction");
        System.out.println("2. Modify Pending Transaction");
        System.out.println("3. Return to Main Menu");

        int choice = readInt("Select an option: ", 1, 3);
        if (choice == 3) {
            return;
        }

        Transaction transaction;
        if (choice == 1) {
            Booking booking = selectBookingForTransaction();
            String txId = String.format("T%04d", nextTransactionNumber++);
            transaction = new Transaction(txId, booking);

            if (booking != null) {
                transaction.addItem(booking.getFacilityItem(), 1);
            }
            transactions.put(txId, transaction);
            System.out.println("Transaction created. Transaction ID: " + txId);
        } else {
            transaction = selectPendingTransaction();
            if (transaction == null) {
                return;
            }
        }

        addItemsToTransaction(transaction);
    }


    // Selection booking
    private Booking selectBookingForTransaction() {
        List<Booking> confirmedList = new ArrayList<>();
        for (Booking b : bookings.values()) {
            if (b.getStatus() == BookingStatus.CONFIRMED) {
                confirmedList.add(b);
            }
        }


        // Walk in booking
        if (confirmedList.isEmpty()) {
            System.out.println("No confirmed bookings available. Creating a walk-in transaction.");
            return null;
        }

        System.out.println("1. Link a confirmed booking");
        System.out.println("2. Walk-in transaction");
        if (readInt("Select an option: ", 1, 2) == 2) {
            return null;
        }

        for (Booking b : confirmedList) {
            System.out.printf("%s | %s | %s | %s %s | %d participant(s)/n",
                    b.getBookingId(), b.getCustomerName(), b.getFacilityItem().getItemName(),
                    b.getBookingDate(), b.getBookingTime(), b.getParticipants());
        }

        while (true) {
            String id = readNonBlank("Booking ID (or 0 for walk-in): ").toUpperCase();
            if (id.equals("0")) {
                return null;
            }
            Booking selected = bookings.get(id);
            if (selected != null && selected.getStatus() == BookingStatus.CONFIRMED) {
                return selected;
            }
            System.out.println("Invalid or inactive booking ID. Try again or enter 0 for walk-in.");
        }
    }


    // Checking out
    private Transaction selectPendingTransaction() {
        List<Transaction> pendingList = new ArrayList<>();
        for (Transaction tx : transactions.values()) {
            if (tx.getPaymentStatus() == PaymentStatus.PENDING) {
                pendingList.add(tx);
            }
        }

        if (pendingList.isEmpty()) {
            System.out.println("No pending transactions found.");
            return null;
        }

        for (Transaction tx : pendingList) {
            System.out.printf("%s | %d item type(s) | Gross %s/n",
                    tx.getTransactionId(), tx.getLineItems().size(), formatMoney(tx.getGrossSubtotal()));
        }

        String id = readNonBlank("Transaction ID: ").toUpperCase();
        Transaction transaction = transactions.get(id);
        if (transaction == null || transaction.getPaymentStatus() != PaymentStatus.PENDING) {
            System.out.println("Pending transaction not found.");
            return null;
        }
        return transaction;
    }

    private void addItemsToTransaction(Transaction transaction) {
        while (true) {
            showCatalogue();
            System.out.println("Enter 0 as the item code when finished.");
            String code = readNonBlank("Item code: ").toUpperCase();
            if (code.equals("0")) {
                break;
            }

            Item item = findItem(code);
            if (item == null) {
                System.out.println("Unknown item code.");
                continue;
            }

            int quantity = readInt("Quantity: ", 1, 100);
            transaction.addItem(item, quantity);
            System.out.printf("%s x %d added. Current gross subtotal: %s/n",
                    item.getItemName(), quantity, formatMoney(transaction.getGrossSubtotal()));
        }
    }

    private void checkout() {
        Transaction transaction = selectPendingTransaction();
        if (transaction == null) {
            return;
        }
        if (transaction.getLineItems().isEmpty()) {
            System.out.println("Add at least one item before checking out this transaction.");
            return;
        }


        // paying menu
        printReceipt(transaction, false);
        System.out.println("\nPayment method: 1. Cash  2. Card  3. E-Wallet");
        int choice = readInt("Select payment method: ", 1, 3);

        PaymentMethod payment;
        if (choice == 1) {
            payment = new CashPayment();
        } else if (choice == 2) {
            payment = new CardPayment();
        } else {
            payment = new EWalletPayment();
        }


        // reads promotion
        double payableAmount = transaction.getFinalPayableAmount(promotions);
        if (payment.processPayment(payableAmount, scanner)) {
            transaction.markPaid(payment.getMethodName(), payment.getPaymentDetails());
            printReceipt(transaction, true);
        } else {
            System.out.println("Payment was not completed. Transaction remains pending.");
        }
    }


    // receipt menu
    private void printReceipt(Transaction tx, boolean isPaid) {
        List<Promotion> eligiblePromos = tx.getEligiblePromotions(promotions);
        Promotion bestPromo = tx.getBestPromotion(promotions);
        double bestSaving = tx.getBestSaving(promotions);

        System.out.println("\n================ ACTIVEHUB RECEIPT ================");
        System.out.println("Transaction: " + tx.getTransactionId());
        if (tx.getBooking() != null) {
            System.out.println("Booking: " + tx.getBooking().getBookingId());
            System.out.println("Customer: " + tx.getBooking().getCustomerName());
        } else {
            System.out.println("Transaction type: Walk-in");
        }

        System.out.printf("%-24s %10s %5s %12s/n", "Item", "Unit Price", "Qty", "Subtotal");
        System.out.println("---------------------------------------------------");
        for (TransactionLineItem line : tx.getLineItems()) {
            System.out.printf("%-24s %10s %5d %12s/n",
                    line.getItem().getItemName(),
                    formatMoney(line.getItem().getRentalPrice()),
                    line.getQuantity(),
                    formatMoney(line.getSubtotal()));
        }
        System.out.println("---------------------------------------------------");
        System.out.println("Gross Subtotal:          " + formatMoney(tx.getGrossSubtotal()));

        System.out.println("Eligible promotions:");
        if (eligiblePromos.isEmpty()) {
            System.out.println("  None");
        } else {
            for (Promotion p : eligiblePromos) {
                System.out.printf("  %s - %s: %s/n",
                        p.getCode(), p.getName(), formatMoney(p.calculateSaving(tx)));
            }
        }

        if (bestPromo == null) {
            System.out.println("Best Promotion:           None");
        } else {
            System.out.printf("Best Promotion:           %s - %s/n", bestPromo.getCode(), bestPromo.getName());
        }

        System.out.println("Promotion Deduction:     -" + formatMoney(bestSaving));
        System.out.println("Discounted Subtotal:      " + formatMoney(tx.getDiscountedSubtotal(promotions)));
        System.out.println("Service Charge (10%):     " + formatMoney(tx.getServiceCharge(promotions)));
        System.out.println("Final Payable Amount:     " + formatMoney(tx.getFinalPayableAmount(promotions)));

        if (isPaid) {
            System.out.println("Payment Method:           " + tx.getPaymentMethod());
            System.out.println("Payment Details:          " + tx.getPaymentDetails());
            System.out.println("Payment Status:           PAID");
        } else {
            System.out.println("Payment Status:           PENDING");
        }
        System.out.println("===================================================");
    }


    // report summary
    private void showReport() {
        int confirmedCount = 0;
        int cancelledCount = 0;

        for (Booking b : bookings.values()) {
            if (b.getStatus() == BookingStatus.CONFIRMED) {
                confirmedCount++;
            } else if (b.getStatus() == BookingStatus.CANCELLED) {
                cancelledCount++;
            }
        }

        List<Transaction> paidTransactions = new ArrayList<>();
        double totalGross = 0.0;
        double totalDiscounts = 0.0;
        double totalService = 0.0;
        double totalNet = 0.0;

        Map<String, Integer> itemCounts = new HashMap<>();

        for (Transaction tx : transactions.values()) {
            if (tx.getPaymentStatus() == PaymentStatus.PAID) {
                paidTransactions.add(tx);
                totalGross += tx.getGrossSubtotal();
                totalDiscounts += tx.getBestSaving(promotions);
                totalService += tx.getServiceCharge(promotions);
                totalNet += tx.getFinalPayableAmount(promotions);

                for (TransactionLineItem line : tx.getLineItems()) {
                    String code = line.getItem().getItemCode();
                    int currentQty = itemCounts.getOrDefault(code, 0);
                    itemCounts.put(code, currentQty + line.getQuantity());
                }
            }
        }


        // most rented item loop
        String mostRentedItem = "None";
        int maxUnits = 0;
        for (Map.Entry<String, Integer> entry : itemCounts.entrySet()) { // Iterates through every key value pair
            if (entry.getValue() > maxUnits) {
                maxUnits = entry.getValue();
                Item item = findItem(entry.getKey());
                if (item != null) {
                    mostRentedItem = item.getItemName() + " (" + maxUnits + " unit(s))";
                }
            }
        }

        System.out.println("\n========== END-OF-DAY MANAGER SUMMARY ==========");
        System.out.printf("Facility bookings:        %d confirmed, %d cancelled/n", confirmedCount, cancelledCount);
        System.out.println("Paid rental transactions:  " + paidTransactions.size());
        System.out.println("Daily gross revenue:       " + formatMoney(totalGross));
        System.out.println("Total discounts given:     " + formatMoney(totalDiscounts));
        System.out.println("Service charges collected: " + formatMoney(totalService));
        System.out.println("Total net revenue:         " + formatMoney(totalNet));
        System.out.println("Most rented catalogue item: " + mostRentedItem);

        System.out.println("\nPayment method breakdown:");
        String[] methods = {"Cash", "Card", "E-Wallet"};
        for (String method : methods) {
            int count = 0;
            double methodRevenue = 0.0;
            for (Transaction tx : paidTransactions) {
                if (method.equals(tx.getPaymentMethod())) {
                    count++;
                    methodRevenue += tx.getFinalPayableAmount(promotions);
                }
            }
            System.out.printf("  %-10s %3d payment(s), %s revenue/n",
                    method, count, formatMoney(methodRevenue));
        }
        System.out.println("================================================");
    }


    // Method definitions, prevent crashing

    private void showCatalogue() {
        System.out.println("\n--- Rental Catalogue ---");
        System.out.printf("%-6s %-26s %-12s %10s /n", "Code", "Item", "Category", "Price");
        for (Item item : catalogue) {
            System.out.printf("%-6s %-26s %-12s %10s /n",
                    item.getItemCode(), item.getItemName(), item.getCategory(), formatMoney(item.getRentalPrice()));
        }
    }

    private void showFacilities() {
        System.out.println("Available facilities:");
        for (Item item : catalogue) {
            if (item.getCategory() == ItemCategory.FACILITY) {
                System.out.printf("  %s - %s (%s) /n",
                        item.getItemCode(), item.getItemName(), formatMoney(item.getRentalPrice()));
            }
        }
    }

    private Item findItem(String code) {
        for (Item item : catalogue) {
            if (item.getItemCode().equalsIgnoreCase(code)) {
                return item;
            }
        }
        return null;
    }

    private String readNonBlank(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("This value cannot be blank.");
        }
    }

    private int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException e) {

            }
            System.out.printf("Please enter a whole number between %d and %d. /n", min, max);
        }
    }

    private LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return LocalDate.parse(scanner.nextLine().trim());
            } catch (DateTimeParseException e) {
                System.out.println("Enter a valid date in yyyy-MM-dd format.");
            }
        }
    }

    private LocalTime readTime(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return LocalTime.parse(scanner.nextLine().trim());
            } catch (DateTimeParseException e) {
                System.out.println("Enter a valid time in HH:mm format.");
            }
        }
    }

    private String formatMoney(double amount) {
        return String.format("RM %.2f", amount);
    }
}