package ActiveHubModel;

import ActiveHubPromo.Promotion;
import java.util.ArrayList;
import java.util.List;

public class Transaction {
    private static final double SERVICE_CHARGE_RATE = 0.10;

    private String transactionId;
    private Booking booking;
    private List<TransactionLineItem> lineItems;
    private PaymentStatus paymentStatus;
    private String paymentMethod;
    private String paymentDetails;

    public Transaction(String transactionId, Booking booking) {
        this.transactionId = transactionId;
        this.booking = booking;
        this.lineItems = new ArrayList<>();
        this.paymentStatus = PaymentStatus.PENDING;
    }

    public void addItem(Item item, int quantity) {
        // Check if the item already exists in the cart
        for (TransactionLineItem line : lineItems) {
            if (line.getItem().getItemCode().equalsIgnoreCase(item.getItemCode())) {
                line.addQuantity(quantity);
                return;
            }
        }
        lineItems.add(new TransactionLineItem(item, quantity));
    }

    public double getGrossSubtotal() {
        double total = 0.0;
        for (TransactionLineItem line : lineItems) {
            total += line.getSubtotal();
        }
        return total;
    }

    public double getFacilitySubtotal() {
        double total = 0.0;
        for (TransactionLineItem line : lineItems) {
            if (line.getItem().getCategory() == ItemCategory.FACILITY) {
                total += line.getSubtotal();
            }
        }
        return total;
    }

    public List<Promotion> getEligiblePromotions(List<Promotion> allPromotions) {
        List<Promotion> eligible = new ArrayList<>();
        for (Promotion promo : allPromotions) {
            if (promo.isEligible(this)) {
                eligible.add(promo);
            }
        }
        return eligible;
    }

    public Promotion getBestPromotion(List<Promotion> allPromotions) {
        Promotion bestPromo = null;
        double bestSaving = 0.0;

        for (Promotion promo : allPromotions) {
            if (promo.isEligible(this)) {
                double saving = promo.calculateSaving(this);
                if (saving > bestSaving) {
                    bestSaving = saving;
                    bestPromo = promo;
                }
            }
        }
        return bestPromo;
    }

    public double getBestSaving(List<Promotion> allPromotions) {
        Promotion best = getBestPromotion(allPromotions);
        if (best == null) {
            return 0.0;
        }
        return best.calculateSaving(this);
    }

    public double getDiscountedSubtotal(List<Promotion> allPromotions) {
        double discounted = getGrossSubtotal() - getBestSaving(allPromotions);
        if (discounted < 0) {
            return 0.0;
        }
        return discounted;
    }

    public double getServiceCharge(List<Promotion> allPromotions) {
        return getDiscountedSubtotal(allPromotions) * SERVICE_CHARGE_RATE;
    }

    public double getFinalPayableAmount(List<Promotion> allPromotions) {
        return getDiscountedSubtotal(allPromotions) + getServiceCharge(allPromotions);
    }

    public void markPaid(String paymentMethod, String paymentDetails) {
        this.paymentMethod = paymentMethod;
        this.paymentDetails = paymentDetails;
        this.paymentStatus = PaymentStatus.PAID;
    }
    public String getTransactionId() {
        return transactionId;
    }
    public Booking getBooking() {
        return booking;
    }
    public List<TransactionLineItem> getLineItems() {
        return lineItems;
    }
    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }
    public String getPaymentMethod() {
        return paymentMethod;
    }
    public String getPaymentDetails() {
        return paymentDetails;
    }
}