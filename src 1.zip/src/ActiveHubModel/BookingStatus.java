package ActiveHubModel;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED
}