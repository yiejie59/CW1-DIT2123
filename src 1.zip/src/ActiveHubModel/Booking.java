package ActiveHubModel;

import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {
    private String bookingId;
    private String customerName;
    private String contactNumber;
    private LocalDate bookingDate;
    private LocalTime bookingTime;
    private int participants;
    private Item facilityItem;
    private BookingStatus status;

    public Booking(String bookingId, String customerName, String contactNumber,
                   LocalDate bookingDate, LocalTime bookingTime, int participants, Item facilityItem) {
        this.bookingId = bookingId;
        this.customerName = customerName;
        this.contactNumber = contactNumber;
        this.bookingDate = bookingDate;
        this.bookingTime = bookingTime;
        this.participants = participants;
        this.facilityItem = facilityItem;
        this.status = BookingStatus.CONFIRMED;
    }

    public void cancel() {
        this.status = BookingStatus.CANCELLED;
    }

    public String getBookingId() {
        return bookingId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public LocalTime getBookingTime() { return bookingTime; }
    public int getParticipants() {
        return participants;
    }

    public Item getFacilityItem() {
        return facilityItem;
    }

    public BookingStatus getStatus() {
        return status;
    }
}