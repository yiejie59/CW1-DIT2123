package ActiveHubModel;

public enum ItemCategory {
    EQUIPMENT,
    FACILITY,
    ACCESSORY
}