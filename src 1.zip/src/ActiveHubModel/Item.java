package ActiveHubModel;

public class Item {
    private String itemCode;
    private String itemName;
    private ItemCategory category;
    private double rentalPrice;

    public Item(String itemCode, String itemName, ItemCategory category, double rentalPrice) {
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.category = category;
        this.rentalPrice = rentalPrice;
    }
    public String getItemCode() {
        return itemCode;
    }
    public String getItemName() {
        return itemName;
    }
    public ItemCategory getCategory() {
        return category;
    }
    public double getRentalPrice() {
        return rentalPrice;
    }
}