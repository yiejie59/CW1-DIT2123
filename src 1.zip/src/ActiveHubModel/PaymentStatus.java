package ActiveHubModel;

public enum PaymentStatus {
    PENDING,
    PAID
}