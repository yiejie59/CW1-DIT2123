package ActiveHubModel;

public class TransactionLineItem {
    private Item item;
    private int quantity;

    public TransactionLineItem(Item item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    public void addQuantity(int qty) {
        this.quantity += qty;
    }

    public Item getItem() {
        return item;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getSubtotal() {
        return item.getRentalPrice() * quantity;
    }
}
