package ActiveHubPromo;

import ActiveHubModel.ItemCategory;
import ActiveHubModel.Transaction;
import ActiveHubModel.TransactionLineItem;

public class EquipmentBundlePromotion implements Promotion {
    private static final double FLAT_DISCOUNT = 20.00;

    @Override
    public String getCode() {
        return "PROMO_C";
    }

    @Override
    public String getName() {
        return "Equipment Bundle Discount";
    }

    @Override
    public boolean isEligible(Transaction tx) {
        boolean hasFacility = false;
        int equipmentCount = 0;

        for (TransactionLineItem line : tx.getLineItems()) {
            if (line.getItem().getCategory() == ItemCategory.FACILITY) {
                hasFacility = true;
            } else if (line.getItem().getCategory() == ItemCategory.EQUIPMENT) {
                equipmentCount += line.getQuantity();
            }
        }

        return hasFacility && equipmentCount >= 3;
    }

    @Override
    public double calculateSaving(Transaction tx) {
        double gross = tx.getGrossSubtotal();
        return Math.min(FLAT_DISCOUNT, gross);
    }
}
