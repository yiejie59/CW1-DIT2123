package ActiveHubPromo;

import ActiveHubModel.Transaction;

public class TeamBookingPromotion implements Promotion {
    private static final double PER_PERSON_DISCOUNT = 5.00;
    private static final double MAX_DISCOUNT = 60.00;

    @Override
    public String getCode() {
        return "PROMO_B";
    }

    @Override
    public String getName() {
        return "Team Booking Reward";
    }

    @Override
    public boolean isEligible(Transaction tx) {
        return tx.getBooking() != null && tx.getBooking().getParticipants() >= 8;
    }

    @Override
    public double calculateSaving(Transaction tx) {
        double saving = tx.getBooking().getParticipants() * PER_PERSON_DISCOUNT;
        if (saving > MAX_DISCOUNT) {
            saving = MAX_DISCOUNT;
        }
        if (saving > tx.getFacilitySubtotal()) {
            saving = tx.getFacilitySubtotal();
        }
        return saving;
    }
}
