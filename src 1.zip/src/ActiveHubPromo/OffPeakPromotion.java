package ActiveHubPromo;

import ActiveHubModel.Booking;
import ActiveHubModel.Transaction;
import java.time.DayOfWeek;
import java.time.LocalTime;

public class OffPeakPromotion implements Promotion {
    private static final double DISCOUNT_RATE = 0.15;

    @Override
    public String getCode() {
        return "PROMO_A";
    }

    @Override
    public String getName() {
        return "Off-Peak Saver";
    }

    @Override
    public boolean isEligible(Transaction tx) {
        Booking booking = tx.getBooking();
        if (booking == null) {
            return false;
        }

        // Valid on weekdays between 09:00 and 16:00
        DayOfWeek day = booking.getBookingDate().getDayOfWeek();
        LocalTime time = booking.getBookingTime();

        boolean isWeekday = (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY);
        boolean isOffPeakHours = !time.isBefore(LocalTime.of(9, 0)) && time.isBefore(LocalTime.of(16, 0));

        return isWeekday && isOffPeakHours && tx.getFacilitySubtotal() > 0;
    }

    @Override
    public double calculateSaving(Transaction tx) {
        return tx.getFacilitySubtotal() * DISCOUNT_RATE;
    }
}
