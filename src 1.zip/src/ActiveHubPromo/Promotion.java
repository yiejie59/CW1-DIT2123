package ActiveHubPromo;

import ActiveHubModel.Transaction;

public interface Promotion {
    String getCode();
    String getName();
    boolean isEligible(Transaction tx);
    double calculateSaving(Transaction tx);
}
