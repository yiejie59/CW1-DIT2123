package ActiveHubPayment;

import java.util.Random;
import java.util.Scanner;

public class EWalletPayment implements PaymentMethod {
    private String provider;
    private String referenceNo;

    @Override
    public boolean processPayment(double amount, Scanner scanner) {
        while (true) {
            System.out.print("E-wallet provider (e.g. Touch 'n Go, GrabPay): ");
            provider = scanner.nextLine().trim();
            if (!provider.isEmpty()) {
                break;
            }
            System.out.println("Provider cannot be blank.");
        }

        // Generate a simple random 6 digit reference number
        // the int starts with 100000 to make it 6 digits then adds a random number between
        // 899999 to generate a random number along with "AH" which symbolizes ActiveHubApp
        int randomNum = 100000 + new Random().nextInt(900000);
        referenceNo = "AH-" + randomNum;

        System.out.println("E-wallet payment approved. Reference: " + referenceNo);
        return true;
    }

    @Override
    public String getMethodName() {
        return "E-Wallet";
    }

    @Override
    public String getPaymentDetails() {
        return provider + " (Ref: " + referenceNo + ")";
    }
}
