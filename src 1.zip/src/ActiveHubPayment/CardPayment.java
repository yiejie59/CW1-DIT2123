package ActiveHubPayment;

import java.util.Scanner;

public class CardPayment implements PaymentMethod {
    private String lastFourDigits;

    @Override
    public boolean processPayment(double amount, Scanner scanner) {
        String cardNumber;
        while (true) {
            System.out.print("Enter 16-digit card number: ");
            cardNumber = scanner.nextLine().trim();
            if (cardNumber.matches("\\d{16}")) {
                break;
            }
            System.out.println("Card number must contain exactly 16 digits.");
        }

        String cvv;
        while (true) {
            System.out.print("Enter 3-digit CVV: ");
            cvv = scanner.nextLine().trim();
            if (cvv.matches("\\d{3}")) {
                break;
            }
            System.out.println("CVV must contain exactly 3 digits.");
        }

        lastFourDigits = cardNumber.substring(12);
        System.out.println("Card payment approved.");
        return true;
    }

    @Override
    public String getMethodName() {
        return "Card";
    }

    @Override
    public String getPaymentDetails() {
        return "Card ending in " + lastFourDigits;
    }
}
