package ActiveHubPayment;

import java.util.Scanner;

public class CashPayment implements PaymentMethod {
    private double tendered;
    private double change;

    @Override
    public boolean processPayment(double amount, Scanner scanner) {
        while (true) {
            System.out.print("Cash tendered: RM ");
            String input = scanner.nextLine().trim();
            try {
                tendered = Double.parseDouble(input);
                if (tendered >= amount) {
                    change = tendered - amount;
                    System.out.printf("Change: RM %.2f/n", change);
                    return true;
                } else {
                    System.out.printf("Insufficient cash. Amount due is RM %.2f/n", amount);
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid amount. Please enter a valid number.");
            }
        }
    }

    @Override
    public String getMethodName() {
        return "Cash";
    }

    @Override
    public String getPaymentDetails() {
        return String.format("Cash tendered RM %.2f; change RM %.2f", tendered, change);
    }
}
