package ActiveHubPayment;

import java.util.Scanner;

public interface PaymentMethod {
    boolean processPayment(double amount, Scanner scanner);
    String getMethodName();
    String getPaymentDetails();
}